# ccplatformer
A platformer game written in python for a school project.

Authors: Jesse, Steven & Corné (cc team).
