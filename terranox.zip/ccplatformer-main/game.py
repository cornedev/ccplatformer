import pygame
import sys
import time

pygame.init()
pygame.mixer.init()

gamew = 1000
gameh = 700

gamescreen = pygame.display.set_mode((gamew, gameh))
gameicon = pygame.image.load("gfx/icon.png").convert_alpha()
pygame.display.set_icon(gameicon)
pygame.display.set_caption("ccplatformer")
font = pygame.font.SysFont(None, 40)
gameclock = pygame.time.Clock()
gamefps = 60

camerax = 0
cameray = 0

worldw = 4000
worldh = 2000
playerw = 100
playerh = 106
playerx = 200
playery = 200
playerspeed = 5
playergravity = 1
playervely = 0
playerjump = -18
coin_count = 0
player_imgs = [
    pygame.image.load("gfx/player1.png").convert_alpha(),
    pygame.image.load("gfx/player2.png").convert_alpha(),
    pygame.image.load("gfx/player3.png").convert_alpha(),
]
player_img_index = 0
player_img = player_imgs[player_img_index]
player = pygame.transform.scale(player_img, (playerw, playerh))
player = pygame.transform.scale(player_img, (playerw, playerh))
playerrect = player.get_rect(topleft=(playerx, playery))

you_won = False
you_lose = False
fading = False
docent_change = False
fade_alpha = 0
current_music = "sfx/bgmusic.mp3"
music_volume = 0.5
last_docent_switch = 0
docent_interval = 300
current_player = "player1"


floor = pygame.image.load("gfx/floor.png").convert_alpha()
def floorcreate(floorx, floory, floorw, floorh):
    floorimg = pygame.transform.scale(floor, (floorw, floorh))
    floorrect = floorimg.get_rect(topleft=(floorx, floory))
    return (floorimg, floorrect)

falsefloor = pygame.image.load("gfx/falsefloor.png").convert_alpha()
def falsefloorcreate(falsefloorx, falsefloory, falsefloorw, falsefloorh):
    falsefloorimg = pygame.transform.scale(falsefloor, (falsefloorw, falsefloorh))
    falsefloorrect = falsefloorimg.get_rect(topleft=(falsefloorx, falsefloory))
    return (falsefloorimg, falsefloorrect)

finish = pygame.image.load("gfx/finish.png").convert_alpha()
def finishcreate(finishx, finishy, finishw, finishh):
    finishimg = pygame.transform.scale(finish, (finishw, finishh))
    finishrect = finishimg.get_rect(topleft=(finishx, finishy))
    return (finishimg, finishrect)

coin = pygame.image.load("gfx/coin.png").convert_alpha()
def coincreate(coinx, coiny, coinw, coinh):
    coinimg = pygame.transform.scale(coin, (coinw, coinh))
    coinrect = coinimg.get_rect(topleft=(coinx, coiny))
    return (coinimg, coinrect)

floors = [
    floorcreate(0, 600, 4000, 100),
    floorcreate(600, 450, 800, 100),
    floorcreate(1600, 350, 800, 100),
]
falsefloors = [
    falsefloorcreate(2500, 200, 800, 100),
]
finishs = [
    finishcreate(3000, 420, 277, 180),
]
coins = [
    coincreate(600, 300, 64, 77),
]

white = (255, 255, 255)
blue = (135, 206, 235)

ground = True
gamerunning = True
pygame.mixer.music.load(current_music)
pygame.mixer.music.set_volume(music_volume)
pygame.mixer.music.play(-1)
while gamerunning:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            gamerunning = False
    
        if event.type == pygame.KEYDOWN:


            if event.key == pygame.K_q:
                pygame.quit()
                sys.exit()
            if event.key == pygame.K_r:
                playerx = 200
                playery = 200
                you_lose = False
                you_won = False
                fading = False
                fade_alpha = 0
                playerspeed = 5
            if event.key == pygame.K_m:
                if current_music == "sfx/bgmusic.mp3":
                    current_music = "sfx/bgmusic2.mp3"
                elif current_music == "sfx/bgmusic2.mp3":
                    current_music = "sfx/bgmusic3.mp3"
                elif current_music == "sfx/bgmusic3.mp3":
                    current_music = "sfx/bgmusic4.mp3"
                elif current_music == "sfx/bgmusic4.mp3":
                    current_music = "sfx/bgmusic5.mp3"
                elif current_music == "sfx/bgmusic5.mp3":
                    current_music = "sfx/bgmusic.mp3"
                pygame.mixer.music.stop()
                pygame.mixer.music.load(current_music)
                pygame.mixer.music.play(-1)
            if event.key == pygame.K_n:
                if current_music == "sfx/bgmusic.mp3":
                    current_music = "sfx/bgmusic5.mp3"
                elif current_music == "sfx/bgmusic5.mp3":
                    current_music = "sfx/bgmusic4.mp3"
                elif current_music == "sfx/bgmusic4.mp3":
                    current_music = "sfx/bgmusic3.mp3"
                elif current_music == "sfx/bgmusic3.mp3":
                    current_music = "sfx/bgmusic2.mp3"
                elif current_music == "sfx/bgmusic2.mp3":
                    current_music = "sfx/bgmusic.mp3"
                pygame.mixer.music.stop()
                pygame.mixer.music.load(current_music)
                pygame.mixer.music.play(-1)
            if event.key == pygame.K_f:
                player_img_index += 1
            if player_img_index >= len(player_imgs):
                player_img_index = 0
            gamedx = 0
            if event.key == pygame.K_RSHIFT:
                playerspeed = 300
                gamedx = playerspeed
            playerrect.x += gamedx
            if event.key == pygame.K_LSHIFT:
                playerspeed = 300
                gamedx = -playerspeed
            playerrect.x += gamedx



            player_img = player_imgs[player_img_index]
            player = pygame.transform.scale(player_img, (playerw, playerh))


            if player_img_index == 0:
                current_player = "player1"
            elif player_img_index == 1:
                current_player = "player2"
            elif player_img_index == 2:
                current_player = "player3"


            if current_player == "player1":
                playerspeed = 5
                playerjump = -18
            elif current_player == "player2":
                playerspeed = 20
                playerjump = -18
            elif current_player == "player3":
                playerspeed = 5
                playerjump = -28






    gewonnen_text = font.render(f"you won", True, (255, 255, 255))
    verloren_text = font.render(f"you lost", True, (255, 255, 255))
    coin_text = font.render(f"your money: {coin_count}", True, (white))


    gamedx = 0
    gameinput = pygame.key.get_pressed()
    if gameinput[pygame.K_a]:
        gamedx = -playerspeed
    if gameinput[pygame.K_d]:
        gamedx = playerspeed
    playerrect.x += gamedx
    if gameinput[pygame.K_k]:
        music_volume += 0.1
        pygame.mixer.music.set_volume(music_volume)
    if gameinput[pygame.K_l]:
        music_volume -= 0.1
        pygame.mixer.music.set_volume(music_volume)

    
    if docent_change:
        current_time = pygame.time.get_ticks()
        if current_time - last_docent_switch >= docent_interval:
            last_docent_switch = current_time

            player_img_index += 1
            if player_img_index >= len(player_imgs):
                player_img_index = 0

            player_img = player_imgs[player_img_index]
            player = pygame.transform.scale(player_img, (playerw, playerh))

    for floorimg, floorrect in floors:
        if playerrect.colliderect(floorrect):
            if gamedx > 0:
                playerrect.right = floorrect.left
            if gamedx < 0:
                playerrect.left = floorrect.right
    if gameinput[pygame.K_SPACE] and ground and not you_lose and not you_won:
        playervely = playerjump
        ground = False

    for falsefloorimg, falsefloorrect in falsefloors:
        if playerrect.colliderect(falsefloorrect):
            you_lose = True
            playerspeed = 0
            fading = True
    for finishimg, finishrect in finishs:
        if playerrect.colliderect(finishrect):
            you_won = True
            playerspeed = 0
            fading = True
    for coin in coins[:]:
        coinimg, coinrect = coin
        if playerrect.colliderect(coinrect):
            coin_count += 1
            coins.remove(coin)
            

    playervely += playergravity
    playerrect.y += playervely
    ground = False
    for floorimg, floorrect in floors:
        if playerrect.colliderect(floorrect):
            if playervely > 0:
                playerrect.bottom = floorrect.top
                playervely = 0
                ground = True
            elif playervely < 0:
                playerrect.top = floorrect.bottom
                playervely = 0

    camerax = playerrect.centerx - gamew // 2
    camerax = max(0, min(camerax, worldw - gamew))

    gamescreen.fill(blue)
    gamescreen.blit(player, (playerrect.x - camerax, playerrect.y - cameray))
    for floorimg, floorrect in floors:
        gamescreen.blit(floorimg, (floorrect.x - camerax, floorrect.y - cameray))
    for falsefloorimg, falsefloorrect in falsefloors:
        gamescreen.blit(falsefloorimg, (falsefloorrect.x - camerax, falsefloorrect.y - cameray))
    for finishimg, finishrect in finishs:
        gamescreen.blit(finishimg, (finishrect.x - camerax, finishrect.y - cameray))
    for coinimg, coinrect in coins:
        gamescreen.blit(coinimg, (coinrect.x - camerax, coinrect.y - cameray))
    if fading:
        fade_alpha = min(fade_alpha + 2, 255)
        fade_surface = pygame.Surface((gamew, gameh))
        fade_surface.set_alpha(fade_alpha)
        fade_surface.fill((0, 0, 0))
        gamescreen.blit(fade_surface, (0, 0))
    if you_won:
        gamescreen.blit(gewonnen_text, (425, 350))
    if you_lose:
        gamescreen.blit(verloren_text, (425, 350))
    gamescreen.blit(coin_text, (20, 20))

    pygame.display.flip()
    gameclock.tick(gamefps)

pygame.quit()
sys.exit()
